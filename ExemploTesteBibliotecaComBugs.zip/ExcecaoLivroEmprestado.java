public class ExcecaoLivroEmprestado extends Exception {}
